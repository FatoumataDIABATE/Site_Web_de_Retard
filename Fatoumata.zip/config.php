<?php
class config{
    const SERVEUR ="localhost";
    const BASEDEDONNEES= "retards";
    const UTILISATEUR = "root";
    const MOTDEPASSE = "";
}
